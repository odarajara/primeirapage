# easy-portfolio
Hello! At this tutorial I teach how to make a simple website using only HTML and CSS! 
You can see the video [here](https://www.youtube.com/watch?v=n_Etdr7Dbjs)
You can see the webpage [here](https://adrianasaty.github.io/easy-portfolio/)
Hope you enjoy it!

## Start

## Installation
Don't need to do anything :)

## Authors
Adriana Saty 


## Follow me:
I also do content at [Twitch](https://www.twitch.tv/adrianasaty).
[Youtube](https://www.youtube.com/channel/UCPhVBS-1Uy-wIzj4hmjkcmA)
and [Instagram](https://www.instagram.com/adriana.saty/)


